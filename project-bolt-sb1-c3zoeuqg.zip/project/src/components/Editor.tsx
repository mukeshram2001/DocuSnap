import React, { useEffect, useRef, useState, useCallback } from 'react';
import { fabric } from 'fabric';
import { useSearchParams } from 'react-router-dom';
import { 
  MousePointer,
  Pencil, 
  Square, 
  Circle, 
  Type, 
  Highlighter,
  Undo2,
  Redo2,
  Download,
  Copy,
  FileDown,
  ArrowLeft,
  Eraser,
  Save
} from 'lucide-react';
import { jsPDF } from 'jspdf';
import { useHistory } from '../hooks/useHistory';
import { useLocalStorage } from '../hooks/useLocalStorage';

type Tool = 'select' | 'draw' | 'rectangle' | 'circle' | 'text' | 'highlight' | 'eraser';

interface ToolButton {
  icon: React.ElementType;
  name: Tool;
  label: string;
}

const tools: ToolButton[] = [
  { icon: MousePointer, name: 'select', label: 'Select' },
  { icon: Pencil, name: 'draw', label: 'Draw' },
  { icon: Square, name: 'rectangle', label: 'Rectangle' },
  { icon: Circle, name: 'circle', label: 'Circle' },
  { icon: Type, name: 'text', label: 'Text' },
  { icon: Highlighter, name: 'highlight', label: 'Highlight' },
  { icon: Eraser, name: 'eraser', label: 'Eraser' }
];

const Editor: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fabricCanvasRef = useRef<fabric.Canvas | null>(null);
  const [selectedTool, setSelectedTool] = useState<Tool>('select');
  const [searchParams] = useSearchParams();
  const [color, setColor] = useLocalStorage('docusnap-color', '#000000');
  const [strokeWidth, setStrokeWidth] = useLocalStorage('docusnap-stroke-width', 2);
  const isDrawingRef = useRef(false);
  const startPointRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  
  const { saveState, undo, redo } = useHistory(fabricCanvasRef.current);

  // Memoize the image loading callback
  const loadImage = useCallback((fabricCanvas: fabric.Canvas, imageData: string) => {
    fabric.Image.fromURL(imageData, (img) => {
      const scaleFactor = Math.min(
        fabricCanvas.width! / img.width!,
        fabricCanvas.height! / img.height!
      );

      img.set({
        scaleX: scaleFactor,
        scaleY: scaleFactor,
        originX: 'center',
        originY: 'center',
        left: fabricCanvas.width! / 2,
        top: fabricCanvas.height! / 2
      });

      fabricCanvas.setBackgroundImage(img, fabricCanvas.renderAll.bind(fabricCanvas));
      saveState();
    });
  }, [saveState]);

  // Handle mouse down for shape drawing
  const handleMouseDown = useCallback((e: fabric.IEvent) => {
    if (!fabricCanvasRef.current || selectedTool === 'select' || selectedTool === 'draw') return;

    isDrawingRef.current = true;
    const pointer = fabricCanvasRef.current.getPointer(e.e);
    startPointRef.current = { x: pointer.x, y: pointer.y };

    if (selectedTool === 'text') {
      const text = new fabric.IText('Click to edit', {
        left: pointer.x,
        top: pointer.y,
        fontFamily: 'Inter',
        fontSize: 20,
        fill: color,
        selectable: true,
        editable: true
      });
      fabricCanvasRef.current.add(text);
      fabricCanvasRef.current.setActiveObject(text);
      isDrawingRef.current = false;
      saveState();
    }
  }, [selectedTool, color, saveState]);

  // Handle mouse move for shape drawing
  const handleMouseMove = useCallback((e: fabric.IEvent) => {
    if (!fabricCanvasRef.current || !isDrawingRef.current) return;

    const canvas = fabricCanvasRef.current;
    const pointer = canvas.getPointer(e.e);
    const startPoint = startPointRef.current;

    // Remove the last drawn object
    if (canvas.getObjects().length > 0 && selectedTool !== 'draw') {
      canvas.remove(canvas.getObjects()[canvas.getObjects().length - 1]);
    }

    let obj;
    switch (selectedTool) {
      case 'rectangle':
        obj = new fabric.Rect({
          left: Math.min(startPoint.x, pointer.x),
          top: Math.min(startPoint.y, pointer.y),
          width: Math.abs(pointer.x - startPoint.x),
          height: Math.abs(pointer.y - startPoint.y),
          fill: 'transparent',
          stroke: color,
          strokeWidth
        });
        break;
      case 'circle':
        const radius = Math.sqrt(
          Math.pow(pointer.x - startPoint.x, 2) + 
          Math.pow(pointer.y - startPoint.y, 2)
        ) / 2;
        obj = new fabric.Circle({
          left: startPoint.x,
          top: startPoint.y,
          radius,
          fill: 'transparent',
          stroke: color,
          strokeWidth
        });
        break;
      case 'highlight':
        obj = new fabric.Rect({
          left: Math.min(startPoint.x, pointer.x),
          top: Math.min(startPoint.y, pointer.y),
          width: Math.abs(pointer.x - startPoint.x),
          height: Math.abs(pointer.y - startPoint.y),
          fill: color,
          opacity: 0.3
        });
        break;
    }

    if (obj) {
      canvas.add(obj);
      canvas.renderAll();
    }
  }, [selectedTool, color, strokeWidth]);

  // Handle mouse up for shape drawing
  const handleMouseUp = useCallback(() => {
    if (!fabricCanvasRef.current || !isDrawingRef.current) return;
    
    isDrawingRef.current = false;
    fabricCanvasRef.current.renderAll();
    saveState();
  }, [saveState]);

  // Initialize canvas
  useEffect(() => {
    if (!canvasRef.current || fabricCanvasRef.current) return;

    const fabricCanvas = new fabric.Canvas(canvasRef.current, {
      width: window.innerWidth * 0.8,
      height: window.innerHeight * 0.8,
      backgroundColor: '#f8fafc',
      preserveObjectStacking: true
    });

    fabricCanvasRef.current = fabricCanvas;

    // Load image from URL parameter
    const imageData = searchParams.get('image');
    if (imageData) {
      loadImage(fabricCanvas, imageData);
    }

    // Set up event listeners for shape drawing
    fabricCanvas.on('mouse:down', handleMouseDown);
    fabricCanvas.on('mouse:move', handleMouseMove);
    fabricCanvas.on('mouse:up', handleMouseUp);

    // Save state after each modification
    const handleModification = () => saveState();
    fabricCanvas.on('object:modified', handleModification);
    fabricCanvas.on('object:added', handleModification);
    fabricCanvas.on('object:removed', handleModification);

    // Handle window resize
    const handleResize = () => {
      fabricCanvas.setDimensions({
        width: window.innerWidth * 0.8,
        height: window.innerHeight * 0.8
      });
      fabricCanvas.renderAll();
    };
    window.addEventListener('resize', handleResize);

    return () => {
      fabricCanvas.off('mouse:down', handleMouseDown);
      fabricCanvas.off('mouse:move', handleMouseMove);
      fabricCanvas.off('mouse:up', handleMouseUp);
      fabricCanvas.off('object:modified', handleModification);
      fabricCanvas.off('object:added', handleModification);
      fabricCanvas.off('object:removed', handleModification);
      window.removeEventListener('resize', handleResize);
      fabricCanvas.dispose();
      fabricCanvasRef.current = null;
    };
  }, [searchParams, loadImage, handleMouseDown, handleMouseMove, handleMouseUp, saveState]);

  const handleToolClick = useCallback((tool: Tool) => {
    if (!fabricCanvasRef.current) return;
    
    setSelectedTool(tool);
    const canvas = fabricCanvasRef.current;
    
    // Reset canvas mode
    canvas.isDrawingMode = tool === 'draw';
    canvas.selection = tool === 'select';
    
    // Configure drawing brush
    if (tool === 'draw') {
      canvas.freeDrawingBrush.width = strokeWidth;
      canvas.freeDrawingBrush.color = color;
    }

    // Configure eraser
    if (tool === 'eraser') {
      canvas.isDrawingMode = true;
      canvas.freeDrawingBrush.width = strokeWidth * 2;
      canvas.freeDrawingBrush.color = '#f8fafc'; // Same as background
    }

    // Update object selection
    canvas.getObjects().forEach((obj) => {
      obj.selectable = tool === 'select';
      obj.evented = tool === 'select';
    });
  }, [color, strokeWidth]);

  const exportToPNG = useCallback(() => {
    if (!fabricCanvasRef.current) return;
    const dataURL = fabricCanvasRef.current.toDataURL({
      format: 'png',
      quality: 1,
      multiplier: 2
    });
    const link = document.createElement('a');
    link.download = 'docusnap-export.png';
    link.href = dataURL;
    link.click();
  }, []);

  const exportToPDF = useCallback(() => {
    if (!fabricCanvasRef.current) return;
    const canvas = fabricCanvasRef.current;
    const dataURL = canvas.toDataURL({
      format: 'png',
      quality: 1,
      multiplier: 2
    });
    
    const pdf = new jsPDF({
      orientation: 'landscape',
      unit: 'px',
      format: [canvas.width!, canvas.height!]
    });
    
    pdf.addImage(dataURL, 'PNG', 0, 0, canvas.width!, canvas.height!);
    pdf.save('docusnap-export.pdf');
  }, []);

  const copyToClipboard = useCallback(async () => {
    if (!fabricCanvasRef.current) return;
    try {
      const dataURL = fabricCanvasRef.current.toDataURL({
        format: 'png',
        quality: 1,
        multiplier: 2
      });
      const blob = await (await fetch(dataURL)).blob();
      await navigator.clipboard.write([
        new ClipboardItem({ 'image/png': blob })
      ]);
    } catch (error) {
      console.error('Failed to copy to clipboard:', error);
    }
  }, []);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Top Navigation */}
      <div className="fixed top-0 left-0 right-0 bg-white border-b border-slate-200 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <a href="/" className="flex items-center space-x-2 text-slate-600 hover:text-indigo-600 transition-colors">
              <ArrowLeft className="w-5 h-5" />
              <span>Back</span>
            </a>
            <div className="h-6 w-px bg-slate-200" />
            <span className="text-slate-600 font-medium">DocuSnap Editor</span>
          </div>
          <div className="flex items-center space-x-4">
            <button
              onClick={exportToPNG}
              className="btn-primary flex items-center space-x-2"
            >
              <Save className="w-4 h-4" />
              <span>Save</span>
            </button>
          </div>
        </div>
      </div>

      {/* Toolbar */}
      <div className="fixed left-4 top-24 bg-white rounded-2xl shadow-lg p-2 space-y-2">
        {tools.map((tool) => (
          <button
            key={tool.name}
            onClick={() => handleToolClick(tool.name)}
            className={`p-2 rounded-lg w-10 h-10 flex items-center justify-center transition-all
                       ${selectedTool === tool.name 
                         ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30' 
                         : 'text-slate-600 hover:bg-slate-100'}`}
            title={tool.label}
          >
            <tool.icon className="w-5 h-5" />
          </button>
        ))}

        <div className="h-px bg-slate-200 mx-2" />

        <button
          onClick={undo}
          className="p-2 rounded-lg w-10 h-10 flex items-center justify-center text-slate-600 hover:bg-slate-100"
          title="Undo"
        >
          <Undo2 className="w-5 h-5" />
        </button>
        <button
          onClick={redo}
          className="p-2 rounded-lg w-10 h-10 flex items-center justify-center text-slate-600 hover:bg-slate-100"
          title="Redo"
        >
          <Redo2 className="w-5 h-5" />
        </button>

        <div className="h-px bg-slate-200 mx-2" />

        <div className="p-2" title="Color">
          <input
            type="color"
            value={color}
            onChange={(e) => setColor(e.target.value)}
            className="w-10 h-10 rounded-lg cursor-pointer"
          />
        </div>
      </div>

      {/* Export Tools */}
      <div className="fixed right-4 top-24 bg-white rounded-2xl shadow-lg p-2 space-y-2">
        <button
          onClick={exportToPNG}
          className="p-2 rounded-lg w-10 h-10 flex items-center justify-center text-slate-600 hover:bg-slate-100"
          title="Export PNG"
        >
          <Download className="w-5 h-5" />
        </button>
        <button
          onClick={exportToPDF}
          className="p-2 rounded-lg w-10 h-10 flex items-center justify-center text-slate-600 hover:bg-slate-100"
          title="Export PDF"
        >
          <FileDown className="w-5 h-5" />
        </button>
        <button
          onClick={copyToClipboard}
          className="p-2 rounded-lg w-10 h-10 flex items-center justify-center text-slate-600 hover:bg-slate-100"
          title="Copy to Clipboard"
        >
          <Copy className="w-5 h-5" />
        </button>
      </div>

      {/* Canvas */}
      <div className="pt-24 px-20">
        <div className="bg-white rounded-2xl shadow-xl p-4 flex justify-center">
          <canvas ref={canvasRef} className="max-w-full" />
        </div>
      </div>
    </div>
  );
};

export default Editor;