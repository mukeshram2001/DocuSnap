import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Camera, 
  Shield, 
  Zap, 
  Sparkles,
  Layout,
  Share2,
  ArrowRight
} from 'lucide-react';

const Logo = () => (
  <div className="flex items-center space-x-2 text-indigo-600">
    <Sparkles className="w-8 h-8" />
    <span className="text-2xl font-bold tracking-tight">DocuSnap</span>
  </div>
);

const Feature = ({ icon: Icon, title, description, delay }: { 
  icon: React.ElementType, 
  title: string, 
  description: string,
  delay: string
}) => (
  <div className="card animate-fade-in" style={{ animationDelay: delay }}>
    <Icon className="feature-icon" />
    <h3 className="text-xl font-semibold mb-2">{title}</h3>
    <p className="text-slate-600 leading-relaxed">{description}</p>
  </div>
);

const Landing: React.FC = () => {
  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md z-50 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Logo />
          <div className="flex items-center space-x-6">
            <a href="#features" className="text-slate-600 hover:text-indigo-600 transition-colors">Features</a>
            <Link to="/annotate" className="btn-primary">
              Try Now
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-8 animate-fade-in">
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-slate-900 tracking-tight">
              Capture. Annotate.
              <span className="text-indigo-600"> Share.</span>
            </h1>
            <p className="text-xl text-slate-600 max-w-2xl mx-auto">
              Transform your screenshots into powerful communication tools with our intuitive annotation suite.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
              <Link to="/annotate" className="btn-primary flex items-center space-x-2">
                <span>Start Creating</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
              <a 
                href="#features" 
                className="text-slate-600 hover:text-indigo-600 transition-colors flex items-center space-x-2"
              >
                <span>Learn More</span>
                <Layout className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-white to-slate-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 animate-fade-in">
            <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-4">
              Everything You Need
            </h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              Powerful features that make screenshot annotation a breeze
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Feature
              icon={Camera}
              title="Instant Capture"
              description="Capture full-page or selected regions with a single click. Works on any website."
              delay="0s"
            />
            <Feature
              icon={Zap}
              title="Smart Annotation"
              description="Add text, shapes, and highlights with our intuitive tools. Perfect for documentation."
              delay="0.2s"
            />
            <Feature
              icon={Shield}
              title="Privacy First"
              description="Your data stays in your browser. No uploads, no tracking, just pure functionality."
              delay="0.4s"
            />
            <Feature
              icon={Share2}
              title="Easy Sharing"
              description="Export to PNG or PDF, or copy directly to your clipboard. Share your ideas effortlessly."
              delay="0.6s"
            />
            <Feature
              icon={Layout}
              title="Modern Interface"
              description="A beautiful, intuitive interface that makes annotation a joy. Dark mode included."
              delay="0.8s"
            />
            <Feature
              icon={Sparkles}
              title="Smart Tools"
              description="AI-powered shape recognition and smart snapping make your annotations pixel-perfect."
              delay="1s"
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <div className="card bg-gradient-to-r from-indigo-600 to-violet-600 text-white animate-fade-in">
            <h2 className="text-3xl font-bold mb-4">
              Ready to Transform Your Screenshots?
            </h2>
            <p className="text-lg text-indigo-100 mb-8">
              Join thousands of users who are already creating better documentation with DocuSnap.
            </p>
            <Link 
              to="/annotate" 
              className="inline-flex items-center px-6 py-3 bg-white text-indigo-600 rounded-lg font-medium 
                         shadow-lg shadow-indigo-500/30 hover:bg-indigo-50 transition-all duration-300 
                         hover:-translate-y-0.5 space-x-2"
            >
              <span>Try DocuSnap Free</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 sm:px-6 lg:px-8 border-t border-slate-200">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between">
          <Logo />
          <div className="mt-4 sm:mt-0 text-slate-600">
            Built with ❤️ for the web
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Landing;