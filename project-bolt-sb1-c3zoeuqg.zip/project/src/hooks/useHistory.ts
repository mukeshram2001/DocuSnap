import { useCallback, useRef, useEffect } from 'react';
import { fabric } from 'fabric';

interface HistoryState {
  objects: fabric.Object[];
  background?: fabric.Image | null;
}

export function useHistory(canvas: fabric.Canvas | null) {
  const historyStack = useRef<HistoryState[]>([]);
  const currentStateIndex = useRef(-1);
  const isInitialMount = useRef(true);

  // Initialize history on mount
  useEffect(() => {
    if (canvas && isInitialMount.current) {
      isInitialMount.current = false;
      saveInitialState();
    }
  }, [canvas]);

  const saveInitialState = useCallback(() => {
    if (!canvas) return;
    
    historyStack.current = [{
      objects: [],
      background: canvas.backgroundImage
    }];
    currentStateIndex.current = 0;
  }, [canvas]);

  const saveState = useCallback(() => {
    if (!canvas) return;

    // Remove any states after current index (for new actions after undo)
    historyStack.current = historyStack.current.slice(0, currentStateIndex.current + 1);

    // Save current state
    const state: HistoryState = {
      objects: canvas.getObjects().map(obj => fabric.util.object.clone(obj)),
      background: canvas.backgroundImage
    };

    historyStack.current.push(state);
    currentStateIndex.current++;

    // Limit history size
    if (historyStack.current.length > 50) {
      historyStack.current.shift();
      currentStateIndex.current--;
    }
  }, [canvas]);

  const undo = useCallback(() => {
    if (!canvas || currentStateIndex.current <= 0) return;

    currentStateIndex.current--;
    const state = historyStack.current[currentStateIndex.current];

    canvas.clear();
    if (state.background) {
      canvas.setBackgroundImage(state.background, canvas.renderAll.bind(canvas));
    }
    state.objects.forEach(obj => canvas.add(fabric.util.object.clone(obj)));
    canvas.renderAll();
  }, [canvas]);

  const redo = useCallback(() => {
    if (!canvas || currentStateIndex.current >= historyStack.current.length - 1) return;

    currentStateIndex.current++;
    const state = historyStack.current[currentStateIndex.current];

    canvas.clear();
    if (state.background) {
      canvas.setBackgroundImage(state.background, canvas.renderAll.bind(canvas));
    }
    state.objects.forEach(obj => canvas.add(fabric.util.object.clone(obj)));
    canvas.renderAll();
  }, [canvas]);

  return { saveState, undo, redo };
}