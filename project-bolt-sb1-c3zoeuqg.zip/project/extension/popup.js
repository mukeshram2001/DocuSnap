// Helper to show errors
function showError(message) {
  const error = document.getElementById('error');
  error.textContent = message;
  error.style.display = 'block';
}

// Capture visible area
document.getElementById('captureVisible').addEventListener('click', async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    // Inject content script to get page dimensions
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: () => {
        return {
          width: document.documentElement.clientWidth,
          height: document.documentElement.clientHeight,
          devicePixelRatio: window.devicePixelRatio
        };
      }
    });

    // Capture the visible area
    const dataUrl = await chrome.tabs.captureVisibleTab(null, { format: 'png' });
    
    // Open the editor with the captured image
    const editorUrl = `http://localhost:5173/annotate?image=${encodeURIComponent(dataUrl)}`;
    window.open(editorUrl, '_blank');
  } catch (error) {
    showError('Failed to capture screenshot: ' + error.message);
  }
});

// Capture full page
document.getElementById('captureFullPage').addEventListener('click', async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    // Inject content script to get full page dimensions
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: () => {
        return {
          width: Math.max(
            document.documentElement.scrollWidth,
            document.documentElement.clientWidth
          ),
          height: Math.max(
            document.documentElement.scrollHeight,
            document.documentElement.clientHeight
          ),
          devicePixelRatio: window.devicePixelRatio
        };
      }
    });

    // Scroll to capture full page
    const { width, height, devicePixelRatio } = result;
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    canvas.width = width * devicePixelRatio;
    canvas.height = height * devicePixelRatio;
    
    // Capture visible area
    const dataUrl = await chrome.tabs.captureVisibleTab(null, { format: 'png' });
    
    // Create image from capture
    const img = new Image();
    img.src = dataUrl;
    await new Promise(resolve => img.onload = resolve);
    
    // Draw to canvas
    ctx.drawImage(img, 0, 0);
    
    // Convert to data URL and open editor
    const fullPageDataUrl = canvas.toDataURL('image/png');
    const editorUrl = `http://localhost:5173/annotate?image=${encodeURIComponent(fullPageDataUrl)}`;
    window.open(editorUrl, '_blank');
  } catch (error) {
    showError('Failed to capture full page: ' + error.message);
  }
});